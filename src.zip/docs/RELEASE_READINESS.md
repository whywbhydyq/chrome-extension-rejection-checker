# Release readiness checklist

This project is a static Vite application deployed to Vercel at `https://cws.ymirtool.com/`.

Use this checklist before merging SEO, scanner-rule, dependency, or deployment changes.

## Runtime requirement

The current tooling requires the Node engine declared in `package.json`:

```txt
^20.19.0 || >=22.12.0
```

Do not remove the engine guard unless the Vite toolchain has been intentionally downgraded or replaced.

## Local static checks

Run these checks before release:

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck -- --pretty false
npm run audit:routing
npm run audit:release
npm run audit:seo
npm run audit:geo
node --check scripts/generate-static-seo-pages.mjs
npm audit --omit=dev
npm audit
```

`npm run audit:release` verifies the release-critical static contract:

- Node engine declaration exists.
- Vercel still uses Vite and `dist`.
- Unknown URLs do not rewrite to the homepage.
- Robots and sitemap use the canonical production domain.
- Favicon, app icon, webmanifest, and OG image exist and are referenced.
- Legacy `FAQPage` structured data has not returned.
- SEO route data has concise titles, SERP-ready descriptions, freshness fields, and review methods.
- GEO conventions such as `llms.txt` are checked separately and should warn rather than block release.
- Archive script excludes generated/cache directories.
- Fixture source directories still exist.

## Build and deployment contract

The Vercel build command remains:

```bash
npm run build
```

The build command performs:

```txt
node scripts/audit-vercel-routing.mjs
  -> tsc -b
  -> vite build
  -> node scripts/generate-static-seo-pages.mjs
```

The generated `dist/` output must include route-specific HTML for the SEO/trust routes defined in `vercel.json`.

## Static SEO route contract

Each generated SEO/trust route should expose source-visible metadata and content:

- Route-specific `<title>`.
- Route-specific `<meta name="description">`.
- Canonical URL on `https://cws.ymirtool.com`.
- Open Graph and Twitter card metadata, including image fields.
- Visible `<h1>` and body content.
- Visible `Last updated` where applicable.
- `TechArticle` or `WebPage` JSON-LD plus `BreadcrumbList`.
- Page-specific `TechArticle` or `WebPage` JSON-LD plus `BreadcrumbList`.
- Stable `@id` references to homepage-level Organization / WebSite / WebApplication entities instead of repeating full entity objects on every generated page.
- No `FAQPage` JSON-LD.

## Privacy and analytics contract

The product promise remains:

> Runs locally. Your extension never leaves your browser.

Analytics may record only aggregate interaction data. Do not send any of the following:

- ZIP contents.
- Manifest content.
- Source snippets.
- File names or file paths.
- Extension names, IDs, or package metadata.
- Detected URLs from the scanned package.

## Archive contract

`npm run build:archives` creates local ZIP fixtures and `src.zip` for local distribution. The archive script must continue to exclude:

- `node_modules`
- `dist`
- `.git`
- `.vercel`
- `.seo-cache`
- `coverage`

`src.zip` should include enough project metadata to reinstall and inspect the source, including:

- `package.json`
- `package-lock.json`
- source files
- public assets
- scripts
- docs
- README / quickstart / requirements files

## Manual production spot checks

After deployment, inspect the source HTML for these URLs:

```bash
curl -L https://cws.ymirtool.com/
curl -L https://cws.ymirtool.com/manifest-v3-pre-submission-checklist
curl -L https://cws.ymirtool.com/fix-remote-hosted-code-manifest-v3
curl -L https://cws.ymirtool.com/privacy
curl -L https://cws.ymirtool.com/sitemap.xml
curl -L https://cws.ymirtool.com/robots.txt
```

Confirm canonical URLs, route-specific metadata, structured data, sitemap entries, favicon references, and social image references.

## Scanner correctness spot checks

Use fixture ZIPs for a manual smoke pass:

- `fixtures/valid-mv3-extension.zip` should have no High findings.
- `fixtures/remote-script-extension.zip` should report remote hosted executable code.
- `fixtures/eval-extension.zip` should report dynamic string-code execution.
- `fixtures/packaging-mistake-extension.zip` should report nested manifest packaging.
- `fixtures/missing-manifest-extension.zip` should report missing manifest.

These are manual release checks, not a replacement for targeted unit tests.
