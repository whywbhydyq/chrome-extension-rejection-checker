# Advanced SEO / GEO Optimization Pass

Date: 2026-06-06

This pass extends the prompt-by-prompt SEO work with a deliberately conservative GEO layer. The goal is to make the site easier for search engines and AI readers to understand without treating experimental AI-reader conventions as ranking levers or release blockers.

## Implemented changes

### Guide hub and internal architecture

- Added `/guides` as a static guide hub for the Manifest V3 review workflow.
- Linked the hub from the React homepage navigation, footer, static homepage fallback, and guide pages.
- Added `/guides` to `public/sitemap.xml` and `vercel.json` explicit rewrites.
- Kept unknown URLs from rewriting to the homepage.

### GEO / AI-reader readiness

- Added `public/llms.txt` as an optional AI-reader map with primary pages, key facts, and source basis.
- Kept `robots.txt` minimal. `User-agent: *` already allows compliant crawlers, so individual AI bot allow rules are intentionally not repeated.
- Added `npm run audit:geo` for optional GEO checks. It warns about `llms.txt` and explicit AI crawler rules rather than blocking release.

### Structured data and entity consistency

- Kept the complete Organization / WebSite / WebApplication entity graph on the homepage.
- Reduced non-home generated pages to page-specific `TechArticle` or `WebPage` plus `BreadcrumbList`, using stable `@id` references for shared entities.
- Added `ItemList` JSON-LD for `/guides` so the hub describes its guide set explicitly.
- Preserved the previous removal of `FAQPage` JSON-LD.

### Programmatic page quality guardrails

- Added static checks requiring SEO data pages to include last-updated metadata, concise titles, practical descriptions, and enough visible body content.
- Extracted repeated source and related-link objects into shared data to reduce maintenance drift.
- Capped related-link output on normal guide pages so internal linking remains intentional instead of exhaustive.

## Verification commands used

No production build was run and no test suite was run.

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck -- --pretty false
npm run audit:routing
npm run audit:release
npm run audit:seo
npm run audit:geo
node --check scripts/generate-static-seo-pages.mjs
node --check scripts/build-archives.mjs
npm audit --omit=dev --json
npm audit --json
```

## Deployment notes

After deployment, manually verify:

1. `https://cws.ymirtool.com/guides`
2. `https://cws.ymirtool.com/llms.txt`, if the optional file remains published
3. `https://cws.ymirtool.com/robots.txt`
4. `https://cws.ymirtool.com/sitemap.xml`
5. One guide page's JSON-LD contains `TechArticle` and `BreadcrumbList`, but not `FAQPage`.
6. `/guides` JSON-LD contains `ItemList` and `BreadcrumbList`.
