# Chrome Extension Rejection Checker

Free local Chrome Web Store preflight scanner for Manifest V3 extension `.zip` files.

Production URL:

https://cws.ymirtool.com/

Vercel fallback URL:

https://chrome-extension-rejection-checker.vercel.app/

## Trust promise

Runs locally. Your extension never leaves your browser.

This is a static preflight scan only. It is not an official Chrome Web Store validator and cannot guarantee approval.

## MVP checks

- Manifest missing / invalid / not MV3
- Manifest not in zip root
- Manifest references missing files
- Remote hosted code risks
- Dynamic string-code execution risks
- Unsafe extension CSP
- Broad host permissions
- Sensitive Chrome API permissions
- Privacy disclosure review reminders
- Icon path existence
- Remote URL manual review list

## SEO and trust pages

Route content is stored in `src/pages/seoPagesData.json` and reused by both the React app and the static SEO generator. This prevents the rendered React page and generated HTML source from drifting.

Generated static routes:

- `/chrome-web-store-rejection-checker`
- `/manifest-v3-pre-submission-checklist`
- `/fix-remote-hosted-code-manifest-v3`
- `/blue-argon-chrome-extension-error`
- `/chrome-extension-eval-rejection-fix`
- `/chrome-extension-host-permissions-privacy-review`
- `/privacy`
- `/how-it-works`

## Runtime requirement

Use a Node version that satisfies the engine guard in `package.json`:

```txt
^20.19.0 || >=22.12.0
```

This guard is required by the current Vite / Vitest toolchain.

## Local development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

The build command runs:

```bash
node scripts/audit-vercel-routing.mjs && tsc -b && vite build && node scripts/generate-static-seo-pages.mjs
```

The final step generates route-specific static HTML pages under `dist/`, including visible body content, page-specific title, description, canonical, Open Graph, Twitter, page-specific TechArticle/WebPage, and BreadcrumbList JSON-LD metadata. Shared Organization, WebSite, and WebApplication entities live on the homepage and are referenced by stable `@id` values from generated pages.

## Generate static SEO pages only

After `vite build` has created `dist/index.html`, you can regenerate the SEO route HTML files manually:

```bash
npm run generate:seo-pages
```

## Release readiness checks

Static release checks that do not create a production build:

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck -- --pretty false
npm run audit:routing
npm run audit:release
npm run audit:seo
npm run audit:geo
node --check scripts/generate-static-seo-pages.mjs
npm audit --omit=dev
npm audit
```

The detailed release checklist is in `docs/RELEASE_READINESS.md`.

## Generate local archives

```bash
npm install
npm run build:archives
```

This creates:

- `src.zip`
- `fixtures.zip`
- `extension-test.zip`
- `fixtures/valid-mv3-extension.zip`
- `fixtures/remote-script-extension.zip`
- `fixtures/dynamic-code-extension.zip`
- `fixtures/eval-extension.zip`
- `fixtures/packaging-mistake-extension.zip`
- `fixtures/missing-manifest-extension.zip`

## Release workflow

1. Confirm the Node version satisfies `package.json` engines.
2. Run the static release checks from `docs/RELEASE_READINESS.md`.
3. Run `npm run build:archives` to generate fixture ZIP files when you need local scanner fixtures.
4. For production release, Vercel runs `npm run build`, which includes the routing audit, TypeScript compile, Vite production build, and static SEO route generation.
5. After deployment, inspect source HTML for the homepage and key static SEO routes.

Manual scanner spot checks:

- Drag `fixtures/valid-mv3-extension.zip` into the page. It should have no High findings.
- Drag `fixtures/remote-script-extension.zip` into the page. It should report CWS001 High.
- Drag `fixtures/eval-extension.zip` into the page. It should report CWS002 High for dynamic string-code execution.
- Drag `fixtures/packaging-mistake-extension.zip` into the page. It should report CWS003 High for nested manifest packaging.
- Drag `fixtures/missing-manifest-extension.zip` into the page. It should report missing manifest.

## Deployment

The project is configured for Vercel with `vercel.json`:

- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- Static route rewrites: each SEO/trust route points to its generated static `index.html`
- SPA fallback: all other routes rewrite to `/index.html`
- Primary production domain: `cws.ymirtool.com`
- Vercel fallback domain: `chrome-extension-rejection-checker.vercel.app`

Every push to `main` triggers a Vercel production deployment through the GitHub integration.

## Deployment verification

After deployment, verify the production HTML source, not only the rendered browser DOM.

Use browser “View Page Source” or curl for each SEO route:

```bash
curl -L https://cws.ymirtool.com/manifest-v3-pre-submission-checklist
curl -L https://cws.ymirtool.com/blue-argon-chrome-extension-error
curl -L https://cws.ymirtool.com/privacy
```

Confirm that each route has its own:

- `<title>`
- `<meta name="description">`
- `<link rel="canonical">`
- `og:url`, `og:title`, `og:description`
- `twitter:title`, `twitter:description`
- Visible static body content such as `<h1>`, guide sections, checklist, examples, visible FAQ content, `Last updated`, and related links
- TechArticle or WebPage JSON-LD plus BreadcrumbList; visible FAQ content is kept on-page without legacy FAQ structured data

The canonical URL for a guide page should point to `https://cws.ymirtool.com/...`, not to the homepage or the Vercel fallback domain.

## Analytics safety

Analytics events are pushed to `window.dataLayer`. Do not send ZIP contents, manifest content, source snippets, file names, file paths, package names, extension IDs, or detected URLs to analytics.

Recommended safe event data:

- Aggregate scan status
- Finding totals by severity
- Rule ID summaries
- Page path
- CTA source component
- Content and rules version

## SEO basics

The app includes:

- Homepage explanatory SEO content
- Static SEO and trust routes generated at build time
- Shared SEO route content data
- Related guide internal links
- Visible FAQ content without legacy FAQPage JSON-LD
- TechArticle/WebPage and BreadcrumbList JSON-LD
- Homepage Organization, WebSite, and WebApplication/SoftwareApplication entity graph
- Favicon, app icon, webmanifest, Open Graph image, and Twitter image metadata
- Optional `public/llms.txt` AI-reader map
- Minimal `public/robots.txt`
- `public/sitemap.xml` with all guide URLs and `lastmod`, without low-value priority fields

When moving to another custom domain, update the canonical domain in:

- `index.html`
- `scripts/generate-static-seo-pages.mjs`
- `public/robots.txt`
- `public/sitemap.xml`
- `README.md`
